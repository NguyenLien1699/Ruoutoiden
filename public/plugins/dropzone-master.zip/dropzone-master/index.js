module.exports = require("./dist/dropzone.js"); // Exposing dropzone
